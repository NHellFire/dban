#ifndef _DISPLAY_H_
#define _DISPLAY_H_

#include "hw.h"

bool scan_display(hwNode & n);
#endif
