#ifndef _PARTITIONS_H_
#define _PARTITIONS_H_

#include "hw.h"

bool scan_partitions(hwNode & n);
#endif
