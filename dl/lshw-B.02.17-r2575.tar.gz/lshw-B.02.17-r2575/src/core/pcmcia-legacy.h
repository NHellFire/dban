#ifndef _PCMCIALEGACY_H_
#define _PCMCIALEGACY_H_

#include "hw.h"

bool scan_pcmcialegacy(hwNode & n);
#endif
