#ifndef _DMI_H_
#define _DMI_H_

#include "hw.h"

bool scan_dmi(hwNode & n);
#endif
