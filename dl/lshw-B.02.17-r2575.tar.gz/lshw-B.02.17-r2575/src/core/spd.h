#ifndef _SPD_H_
#define _SPD_H_

#include "hw.h"

bool scan_spd(hwNode & n);
#endif
