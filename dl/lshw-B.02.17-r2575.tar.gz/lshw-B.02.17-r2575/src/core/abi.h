#ifndef _ABI_H_
#define _ABI_H_

#include "hw.h"

bool scan_abi(hwNode & n);
#endif
