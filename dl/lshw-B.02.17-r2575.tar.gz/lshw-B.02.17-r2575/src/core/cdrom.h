#ifndef _CDROM_H_
#define _CDROM_H_

#include "hw.h"

bool scan_cdrom(hwNode & n);
#endif
