#ifndef _CPUINFO_H_
#define _CPUINFO_H_

#include "hw.h"

bool scan_cpuinfo(hwNode & n);
#endif
