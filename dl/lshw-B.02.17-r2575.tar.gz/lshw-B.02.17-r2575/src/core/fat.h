#ifndef _FAT_H_
#define _FAT_H_

#include "hw.h"
#include "blockio.h"

bool scan_fat(hwNode & n, source & s);

#endif
