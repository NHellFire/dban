#ifndef _ISAPNP_H_
#define _ISAPNP_H_

#include "hw.h"

bool scan_isapnp(hwNode & n);
#endif
