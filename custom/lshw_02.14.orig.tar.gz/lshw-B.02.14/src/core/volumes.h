#ifndef _VOLUMES_H_
#define _VOLUMES_H_

#include "hw.h"
#include "blockio.h"

bool scan_volume(hwNode & n, source & s);

#endif
