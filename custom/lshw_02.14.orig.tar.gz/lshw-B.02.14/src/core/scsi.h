#ifndef _SCSI_H_
#define _SCSI_H_

#include "hw.h"

bool scan_scsi(hwNode & n);
#endif
