#ifndef _USB_H_
#define _USB_H_

#include "hw.h"

bool scan_usb(hwNode & n);
#endif
